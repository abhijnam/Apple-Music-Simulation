Working Methods:

1.File I/O, exception to catch bad file or wrong filename also works

2. Error messages are printed from custom Exception Classes ( AudioContentNotFound, SongNotFound, AudioBookNotFound, PlaylistNotFound, although the last exception wasn't specifically used in the program's methods of download or search)

3.Title Map, Genre Map, Artist Map in AudioContents store

4.Search

5.Searcha, Searchg

6.Download- Modified to include two indicies

7.Downloada

8.Downloadg

I have not done the bonus SearchP(i.e it's related code).
the program complies with the command prompt. All methods work.

