public class AudioContentNotFoundException extends RuntimeException
{
	public AudioContentNotFoundException(String errorMessage)
	{
		super(errorMessage);
	}
}
