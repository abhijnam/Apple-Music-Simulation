public class AudioBookNotFoundException extends RuntimeException
{
	public AudioBookNotFoundException(String errorMessage)
	{
		super(errorMessage);
	}
}
