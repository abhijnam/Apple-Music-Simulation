public class PlayListNotFoundException extends RuntimeException
{
	public PlayListNotFoundException(String errorMessage)
	{
		super(errorMessage);
	}
}
