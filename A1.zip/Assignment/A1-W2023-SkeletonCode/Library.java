import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.lang.model.util.ElementScanner6;
// Student Number: 501191089
// Name: Tejaswini Abhijna Medicharla
/*
 * This class manages, stores, and plays audio content such as songs, podcasts and audiobooks. 
 */
public class Library
{
	private ArrayList<Song> 			songs; 
	private ArrayList<AudioBook> 	audiobooks;
	private ArrayList<Playlist> 	playlists; 
	
  //private ArrayList<Podcast> 	podcasts;
	
	// Public methods in this class set errorMesg string 
	// Error Messages can be retrieved from main in class MyAudioUI by calling  getErrorMessage()
	// In assignment 2 we will replace this with Java Exceptions
	String errorMsg = "";
	
	public String getErrorMessage()
	{
		return errorMsg;
	}

	public Library()
	{
		songs 			= new ArrayList<Song>(); 
		audiobooks 	= new ArrayList<AudioBook>(); ;
		playlists   = new ArrayList<Playlist>();
	  	//podcasts		= new ArrayList<Podcast>(); ;
	}
	/*
	 * Download audio content from the store. Since we have decided (design decision) to keep 3 separate lists in our library
	 * to store our songs, podcasts and audiobooks (we could have used one list) then we need to look at the type of
	 * audio content (hint: use the getType() method and compare to Song.TYPENAME or AudioBook.TYPENAME etc)
	 * to determine which list it belongs to above
	 * 
	 * Make sure you do not add song/podcast/audiobook to a list if it is already there. Hint: use the equals() method
	 * If it is already in a list, set the errorMsg string and return false. Otherwise add it to the list and return true
	 * See the video
	 */
	public boolean download(AudioContent content) // what do I set the error message to
	{
		if(content.getType().equals(Song.TYPENAME) && !songs.contains(content)) // if statement to check what type of audio content is being passed as the parameter and checks to see if that specific audiocontent is alreayd in the arrylist of that audiocontent object
		{
			Song s1 = (Song) content; // since the audio content is a song, we are downcasting to the object to class song so we can add it to the songs arraylist
			songs.add(s1); // songs is an arraylist of Song objects
			return true;
		}
		if(content.getType().equals(AudioBook.TYPENAME)&& !audiobooks.contains(content))// if statement to check what type of audio content is being passed as the parameter and checks to see if that specific audiocontent is alreayd in the arrylist of that audiocontent object
		{
			AudioBook b1 = (AudioBook)content;// since the audio content is an audio book, we are downcasting to the object to class AudioBook  so we can add it to the audiobooks arraylist
			audiobooks.add(b1);// audiobooks is an arrylist of AudioBook objects
			return true;
		}
		if(content.getType().equals(Song.TYPENAME) && songs.contains(content)) // checks to see if the object of class Song is already in arraylist
		{
			errorMsg = "Song already Downloaded"; // if it's  in the arraylist, we are setting the error message to already downloaded
			return false;
		}
		if(content.getType().equals(AudioBook.TYPENAME)&& audiobooks.contains(content))// checks to see if the object of class AudioBook is already in arraylist
		{
			errorMsg = "Audiobook already downloaded";
			return false;
		}
		errorMsg = "Not downloaded";
		return false;
		//return true;
	}
	
	// Print Information (printInfo()) about all songs in the array list
	public void listAllSongs()
	{
		for (int i = 0; i < songs.size(); i++)// loops through song arraylist
		{
			int index = i + 1;
			System.out.print(index + ". "); // prints out index +1
			songs.get(i).printInfo();// prints the information
			System.out.println();
		}
	}
	
	// Print Information (printInfo()) about all audiobooks in the array list
	public void listAllAudioBooks()
	{
		for(int i = 0; i < audiobooks.size();i++)// loops through audiobook arraylist
		{
			int index = i + 1;
			System.out.print(index + ". ");//prints out index+1
			audiobooks.get(i).printInfo();// prints the information
			System.out.println();
		}
	}
	
  // Print Information (printInfo()) about all podcasts in the array list
	public void listAllPodcasts()
	{

	}
	
  // Print the name of all playlists in the playlists array list
	// First print the index number as in listAllSongs() above
	public void listAllPlaylists()
	{
		for(int i = 0; i < playlists.size();i++)// loops through playlists arraylist
		{
			int index = i + 1;
			System.out.print(index + ". ");// prints out index+1
			System.out.println(playlists.get(i).getTitle());// prints out title of playlist

		}
	}
	
  // Print the name of all artists. 
	public void listAllArtists()
	{
		// First create a new (empty) array list of string 
		// Go through the songs array list and add the artist name to the new arraylist only if it is
		// not already there. Once the artist arrayl ist is complete, print the artists names
		ArrayList<String> mystr = new ArrayList<>(); // creating a new list
		for( int i = 0; i < songs.size();i++) // for loop to go through the list of song objects in song arraylist
		{
			if(!mystr.contains(songs.get(i).getArtist()))// if the new arraylist doesn't contain the artist of the object Song that we are trying to add
			{
				mystr.add(songs.get(i).getArtist()); // we are then adding the artist of the song object
			}
		}
		// we are using a for loop to go through the artists of the song object and printing 
		for(int j = 0; j < mystr.size();j++)
		{
			int index = j + 1;
			System.out.print("" + index + ". ");
			System.out.println(mystr.get(j));
			//System.out.println();
		}
	}

	// Delete a song from the library (i.e. the songs list) - 
	// also go through all playlists and remove it from any playlist as well if it is part of the playlist
	public boolean deleteSong(int index)
	{
		if(index > 0 && index-1 < songs.size()) // if statement is used to check if the index in the parameter is valid, since the index of the song objects in the User Interface starts with 1, we are taking that into consideration and checking if the index-1 exists in the songs arraylist
		{
			for(int i = 0; i < playlists.size();i++) // we are checking to see if any playlists were created and stored in the playlists arraylist
			{
				if(playlists.get(i).contains(index))// checks to see if the playlist object contains an index
				{
					for(int j = 0; j < playlists.get(i).getContent().size();j++)// goes through the content that we added to the playlist object 
					{
						if(playlists.get(i).getContent().get(j).getTitle().equalsIgnoreCase(songs.get(index-1).getTitle())); // if the content in the playlist equals the title of the song we want to delete
						{
							playlists.get(i).deleteContent(j+1);// we are then deleting that specific song from that playlist
						}
					}
					songs.remove(index-1);//  we are removing the song regardless if the playlist contains the song or not
					return true;	
				}

			}
		}
		errorMsg = "Song not found in library"; // returns an error message if index is out of range of songs arraylist
		return false;
		// errorMsg = "Song not found";
		// return false;
	}
	// if(playlists.get(i).contains(index))// if a playlist was created and it contained the index of the the song we are deleting
	// 			{
	// 				playlists.get(i).deleteContent(index); // we are removing that song from the playlist as well
	// 				return true;
	// 			}
	
  //Sort songs in library by year
	public void sortSongsByYear()
	{
		// Use Collections.sort() 
		Collections.sort(songs,new SongYearComparator());// inbuilt java method that sorts an arraylist based on a comparator, in this case the class SongLengthComparator
	}
  // Write a class SongYearComparator that implements
	// the Comparator interface and compare two songs based on year
	private class SongYearComparator implements Comparator<Song> // helper class that implements the comparator interface that uses the class song to compare the year of song objects
	{
		public int compare(Song s3, Song s4)// function that returns either a postive or negative value that'll be used to sort the song objects by year
		{
			int s3_year = s3.getYear();
			int s4_year = s4.getYear();
			return s3_year - s4_year;
		}
	}

	// Sort songs by length
	public void sortSongsByLength()
	{
	 // Use Collections.sort() 
	 Collections.sort(songs,new SongLengthComparator()); // inbuilt java method that sorts an arraylist based on a comparator, in this case the class SongLengthComparator
	}
  // Write a class SongLengthComparator that implements
	// the Comparator interface and compare two songs based on length
	private class SongLengthComparator implements Comparator<Song> // helper class that implements the comparator interface and uses the class song to compare the length of song objects
	{
		public int compare(Song s1,Song s2) // function that returns either a postive or negative value that'll be used to sort the song objects by length
		{
			int s1_length = s1.getLength();
			int s2_length = s2.getLength();
			return s1_length-s2_length;
		}
	}

	// Sort songs by title 
	public void sortSongsByName()
	{
	  // Use Collections.sort()
		// class Song should implement the Comparable interface
		// see class Song code
		Collections.sort(songs);// uses the java inbuilt framework, collections to sort the song objects by name, note: each song object will be sorted because it implements the comparable interface
	}

	
	
	/*
	 * Play Content
	 */
	
	// Play song from songs list
	public boolean playSong(int index)
	{
		if (index < 1 || index > songs.size())// checks to see if the index is in range
		{
			errorMsg = "Song Not Found"; // error message is displayed when we get an index out of range
			return false;
		}
		else
		{
			songs.get(index-1).play(); // if index is valid, then the song from the specific index in the songs arraylist of object is played
			return true;
		}
	}
	
	// Play podcast from list (specify season and episode)
	// Bonus
	public boolean playPodcast(int index, int season, int episode)
	{
		return false;
	}
	
	// Print the episode titles of a specified season
	// Bonus 
	public boolean printPodcastEpisodes(int index, int season)
	{
		return false;
	}
	
	// Play a chapter of an audio book from list of audiobooks
	public boolean playAudioBook(int index, int chapter)
	{
		if(index > 0 && index-1 < audiobooks.size()&&audiobooks.contains(audiobooks.get(index-1)))// checks to see if the index is in range
		{
			audiobooks.get(index-1).selectChapter(chapter);// if the index is in range, we select the audiobook at that index and select the chapter
			audiobooks.get(index-1).play();// we play the chapter with the help of the play method in the class AudioBook
			return true;
		}
		else
		{
			errorMsg = "Audiobook not found";// error message is displayed when 
			return false;
		}
	}
	
	// Print the chapter titles (Table Of Contents) of an audiobook
	// see class AudioBook
	public boolean printAudioBookTOC(int index)
	{
		if(index > 0 && index-1 < audiobooks.size()&& audiobooks.contains(audiobooks.get(index-1))) // checking to see if the index is in range and if the audiobooks arraylist contains the specific object at the index that is being passed into the method
		{
			audiobooks.get(index-1).printTOC(); // prints the title of contents of the the audiobook at that specific index in the arraylist
			return true;
		}
		else
		{
			errorMsg = "Audiobook not found"; // otherwise prints error message
			return false;
		}
	}
	
  /*
   * Playlist Related Methods
   */
	
	// Make a new playlist and add to playlists array list
	// Make sure a playlist with the same title doesn't already exist
	public boolean makePlaylist(String title)
	{
		Playlist p = new Playlist(title); // creating a new playlist with the given title in the parameter
		if(!playlists.contains(p))// if the playlist already doesn't contain that specific title
		{
			playlists.add(p); // add the playlist to the arraylist of playlists
			return true;
		}
		errorMsg = "playlist" + " "+ title +" "+  "already exists"; // otherwise print error message
		return false;
	}
	
	// Print list of content information (songs, audiobooks etc) in playlist named title from list of playlists
	public boolean printPlaylist(String title)
	{
		Playlist mypl = new Playlist(title); // creating a new playlist to compare 
		for(int i = 0; i < playlists.size(); i++) // for loop to go through the playlist arraylist
		{
			if(playlists.get(i).equals(mypl)) // if playlist object in arraylist equals the playlist we are comparing it to using equals
			{
				playlists.get(i).printContents(); // print the contents of that playlist and return true
				return true;
			}
		}
		errorMsg ="Playlist"+ title+ "exists"; // otherwise print error message
		return false;

	}
	
	// Play all content in a playlist
	public boolean playPlaylist(String playlistTitle)
	{
		for(int i = 0;i < playlists.size();i++) // for loop to go through the playlist arraylist
		{
			if(playlists.get(i).equals(new Playlist(playlistTitle))) // if playlist object in arraylist equals the playlist we are comparing it to using equals
			{
				playlists.get(i).playAll(); // play the playlist and return true
				return true;
			}
		}
		errorMsg = "Playlist not found"; // otherwise print error message
		return false;
	}
	
	// Play a specific song/audiobook in a playlist
	public boolean playPlaylist(String playlistTitle, int indexInPL)
	{
		for(int i = 0;i < playlists.size();i++) // looping through the playlists arraylist
		{
			if(playlists.get(i).equals(new Playlist(playlistTitle))) // checking to see if the playlist object in the arraylist matches with the new reference object we are creating with the title parameter
			{
				System.out.println(playlists.get(i).getTitle());// prints the playlist title
				playlists.get(i).play(indexInPL);// plays the playlist at the index specified in the parameter of the method
				return true;
			}
		}
		errorMsg = "Playlist not found";
		return false;
	}
	
	// Add a song/audiobook/podcast from library lists at top to a playlist
	// Use the type parameter and compare to Song.TYPENAME etc
	// to determine which array list it comes from then use the given index
	// for that list
	public boolean addContentToPlaylist(String type, int index, String playlistTitle)
	{
		Playlist ply = new Playlist(playlistTitle); // creating a playlist object ply to compare it to the playlist objects in the playlists arraylist
		if(type.equalsIgnoreCase(Song.TYPENAME)) // checking to see the type passed in as the parameter is equal to the string SONG defined by the fixed constant TYPENAME
		{
			if(index > 0 && index-1 < songs.size())// checking to see if the index passed into the method is valid for the arraylist songs in the library
			{
				for(int i = 0; i < playlists.size();i++) // if the index exists in the songs arraylist, loop through the playlists arraylist 
				{
					if(playlists.get(i).equals(ply))// check if any playlist objects in the arraylist matches with the ply object that we created using the playlistTitle
					{
						for(int j = 0; j < playlists.get(i).getContent().size();j++)// goes through the contents of the arraylist
						{
							if(playlists.get(i).getContent().get(j).getTitle().equalsIgnoreCase(songs.get(index-1).getTitle()))// checks if the objects in the contents of the arraylist has the title of the audiocontent ex: song at that index
							{
								errorMsg = "Song already added"; // prints error message if song is already added 
								return false;
							}
							
						}
						playlists.get(i).addContent(songs.get(index-1));// otherwise add the song at that index to that specific playlist object in the playlists
						return true;

					}
				}
				errorMsg = "Playlist not found";
				return false;
			}
		}
		if(type.equalsIgnoreCase(AudioBook.TYPENAME))// checking to see the type passed in as the parameter is equal to the string AUDIOBOOK defined by the fixed constant TYPENAME
		{
			if(index > 0 && index-1 < audiobooks.size())// checking to see if the index passed into the method is valid for the arraylist audiobooks in the library
			{
				for(int i = 0; i < playlists.size();i++)// if the index exists in the songs arraylist, loop through the playlists arraylist 
				{
					if(playlists.get(i).equals(ply))// check if any playlist objects in the arraylist matches with the ply object that we created using the playlistTitle
					{
						for(int j = 0; j < playlists.get(i).getContent().size();j++)
						{
							if(playlists.get(i).getContent().get(j).getTitle().equalsIgnoreCase(audiobooks.get(index-1).getTitle())) // checks if object exists in the arraylist and if the titles are equals
							{
								errorMsg = "Audiobook already added"; // the title was already added prints error message
								return false;
							}
							
						}
						playlists.get(i).addContent(audiobooks.get(index-1));// otherwise add the audiobook at that index to that specific playlist object in the playlists
						return true;
					}
				}
				errorMsg = "Playlist not found"; // incase we didn't create a playlist, this error message will print
				return false;
			}
		}
		errorMsg = "Content not found"; // if we don't pass a valid content type then this message will print
		return false;
	}

  // Delete a song/audiobook/podcast from a playlist with the given title
	// Make sure the given index of the song/audiobook/podcast in the playlist is valid 
	public boolean delContentFromPlaylist(int index, String title)
	{
		Playlist pl1 = new Playlist(title); // creating a new playlists object so the equals method for in class playlist can be invoked
		for(int i = 0; i < playlists.size();i++)// a for loop through the playlists arraylist that contains playlist objects
		{
			if(playlists.get(i).equals(pl1))// checks to see if the object in the playlists arraylist is equal to the object that is being passed as the parameter
			{
				if(playlists.get(i).contains(index))// if the playlists arraylist finds a playlist equal to the object pl1 then we are checking if the object in the playlists arraylist contains the index specified in the parameter
				{
					playlists.get(i).deleteContent(index); // if the index exists, delete the content in that particular playlist
					return true;
				}
			}
		}
		errorMsg = "Playlist not found"; // else print this error message
		return false;
	}
	
}



// if(playlists.get(i).contains(index))// if the playlist exists, check to see if it contains the index being passed
// 						{
// 							playlists.get(i).addContent(audiobooks.get(index-1));// otherwise add the song at that index to that specific playlist object in the playlists
// 							return true;
// 						}