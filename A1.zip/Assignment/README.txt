Working Methods:

1. DOWNLOAD,SONGS,BOOKS

2. PLAYSONG,PLAYBOOK

3.ARTISTS,DELSONG

4.MAKEPL,PRINTPL,ADDTOPL,DELFROMPL,PLAYALLPL,PLAYPL

5.SORTBYLENGTH,SORTBYYEAR

6.SORTBYNAME

I have not done the bonus PODCAST or it's following methods

the program complies with the command prompt. All methods work.

